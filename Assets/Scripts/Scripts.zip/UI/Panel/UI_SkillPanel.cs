using UnityEngine;

/// <summary>
/// ��ų �� �ǳ�
/// </summary>
public class UI_SkillPanel : MonoBehaviour {
    private void Start() {
        gameObject.SetActive(false);
    }
}