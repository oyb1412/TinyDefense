public class StatusBase {
    public int Level { get; set; }
}