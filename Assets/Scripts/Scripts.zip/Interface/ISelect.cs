﻿/// <summary>
/// 선택 가능한 오브젝트 인터페이스 
/// </summary>
public interface ISelect {
    //선택
    void Select();
    //선택 해제
    void DeSelect();
}
